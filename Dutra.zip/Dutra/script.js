if (localStorage.getItem('usuarios') === null) {
    localStorage.setItem('usuarios', JSON.stringify([
        { usuario: 'denis', senha: '123'},
        { usuario: 'joão', senha: '456' },
        { usuario: 'admin', senha: 'admin' }
    ]));
}

function getUsuarios() {
    return JSON.parse(localStorage.getItem('usuarios'));
}

function saveUsuarios(usuarios) {
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
}

document.getElementById('loginform').addEventListener('submit', function login(event) {
    event.preventDefault();

    var user = document.getElementById('user').value;
    var senha = document.getElementById('senha').value;
    var usuarios = getUsuarios();
    var loginValido = false;

    for (var i in usuarios) {
        if (user == usuarios[i].usuario && senha == usuarios[i].senha) {
            loginValido = true;
            break;
        }
    }

    if (loginValido) {
        alert('Usuário Correto');
        location.href = './home.html';
    } else {
        alert('Usuário ou senha incorreto');
    }
});

document.getElementById('register').addEventListener('click', function () {
    var user = document.getElementById('user').value;
    var senha = document.getElementById('senha').value;
    var usuarios = getUsuarios();
    var loginExistente = false;

    for (var i in usuarios) {
        if (user == usuarios[i].usuario) {
            loginExistente = true;
            break;
        }
    }

    if (loginExistente) {
        alert('Usuário já existe');
    } else {
        usuarios.push({ usuario: user, senha: senha });
        saveUsuarios(usuarios);
        alert('Usuário Registrado');
    }
});