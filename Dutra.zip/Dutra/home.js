let ponto = 0;
let ptPClick = 1;

document.getElementById('pontos').addEventListener('click', function (){

    ponto += ptPClick;
    document.getElementById('pontuacao').textContent = 'Pontuacao: ' + ponto;
})

document.getElementById('up').addEventListener('click', function (){

    if(ponto >= 10){

        ptPClick+=1;
        ponto -= 10;

        document.getElementById('pontuacao').textContent = 'Pontuacao: ' + ponto;

    }else {

        alert("Pontos insuficientes");
    }
    
    
    document.getElementById('up2').addEventListener('click', function (){

        if(ponto >= 50){
    
            ptPClick+=5;
            ponto -= 50;
    
            document.getElementById('pontuacao').textContent = 'Pontuacao: ' + ponto;
    
        }else {
    
            alert("Pontos insuficientes");
        }
        
    
    
    })


})


